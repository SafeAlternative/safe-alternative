<?php

global $cities;

$cities['RO'] = array();